﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class05.Exercise1.Enums
{
	public enum Race
	{
		Boxer,
		Bulldog,
		Collie,
		Dalmatian,
		Doberman,
		Mutt,
		Mudi,
		Pointer,
		Pug,
		Plott
	}
}
