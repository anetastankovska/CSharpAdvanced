﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class05.Exercise1.Enums
{
	public enum Job
	{
		Archivist,
		Waiter,
		Choreographer,
		Developer,
		Dentist,
		Sculptor,
		Interpreter,
		Barber
	}
}
