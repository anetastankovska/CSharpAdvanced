﻿// See https://aka.ms/new-console-template for more information
using SEDC.Oop.Class01.Exercise3.Models;

Service service = new Service();
Service.Main();





