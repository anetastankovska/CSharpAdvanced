**Exercise 1: Create a console application that detect provided names in a provided text 🔹**


1. The application should ask for names to be entered until the user enteres x
2. After that the application should ask for a text (sentence)
3. Then the user provides a word from the entered text so the application can check how many times that word is consisted in the text
4. When that is done the application should show how many times that name was included in the text ignoring upper/lower case -->
