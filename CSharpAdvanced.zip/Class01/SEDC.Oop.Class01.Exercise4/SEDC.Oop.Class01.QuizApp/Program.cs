﻿// See https://aka.ms/new-console-template for more information

using SEDC.Oop.Class01.QuizApp.Services;

Console.ResetColor();
Quiz q = new Quiz();
q.MainMenu();

