**Exercise 2: Create a console application that checks if a day is a working day 🔹**

1. The app should request for a user to enter a date as an input or multiple inputs
2. The app should then open and see if the day is a working day
3. It should show the user a message whether the date they entered is working or not
4. Weekends are not working
5. 1 January, 7 January, 20 April, 1 May, 25 May, 3 August, 8 September, 12 October, 23 October and 8 December are not working days as well
6. It should ask the user if they want to check another date
7. Yes - the app runs again
8. No - the app closes
