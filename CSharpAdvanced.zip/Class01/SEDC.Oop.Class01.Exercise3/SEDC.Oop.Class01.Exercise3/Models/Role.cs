﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SEDC.Oop.Class01.Exercise3.Models
{
    public enum Role
    {
        Rock = 1,
        Paper = 2, 
        Scissors = 3,
    }
}
